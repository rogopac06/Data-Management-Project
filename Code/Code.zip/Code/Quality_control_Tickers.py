# Quality control of tickers

import os
import pandas as pd

# Reference files of tickers
Nasdaq_reference_file = "../Dati_file/nasdaq_screener_NASDAQ_filtered.csv"
NYSE_reference_file   = "../Dati_file/nasdaq_screener_NYSE_filtered.csv"

if os.path.isfile(Nasdaq_reference_file) == False:
    print("Nasdaq reference file doesn't exist")    
if os.path.isfile(NYSE_reference_file) == False:
    print("NYSE reference file doesn't exist")



def missing_value_check(_input):
    i=0
    for _ in _input:
        if _ == "" or _ == " ":
           i+=1
    if i == 0:
        print("No missing values in input list")
    else:
        print("Missing values in input list")


def Ref_file_to_list(Nasdaq_reference_file,NYSE_reference_file):
    NYSE_ref_df = pd.read_csv(NYSE_reference_file)
    Nasdaq_ref_df = pd.read_csv(Nasdaq_reference_file)  
    set1 = set()
    set2 = set()
    set1 = set( __ for __ in NYSE_ref_df["Symbol"].values.tolist())
    set2 = set( __ for __ in Nasdaq_ref_df["Symbol"].values.tolist())
    glob_syms = set.union( set1, set2)
    return(glob_syms)

def code_value_check(_input,glob_syms_list):
    i=0
    tmp_set = list(glob_syms_list)
    for _ in _input:
        for __ in glob_syms_list:
            if _ == __ :
                i+=1
                tmp_set.remove(__)
                break
    print( f'Number of not verified tickers is {len( tmp_set )}' )
