
import os
import pandas as pd
from yahoo_fin import stock_info as si

def ETF_file_to_list(ETF_reference_file):
    ETF_ref_df = pd.read_csv(ETF_reference_file)
    set1 = set()
    set1 = set( __ for __ in ETF_ref_df["SYMBOL"].values.tolist())
    return(set1)

def glob_stickers_to_csv(csv_out_file,glob_syms_lists):
    csv_out_file_id = open(csv_out_file,"w")
    csv_out_file_id.write("Number,Symbol")
    csv_out_file_id.write("\n")
    i=0
    for _ in glob_syms_lists:
        i+=1
        csv_out_file_id.write(str(i) + "," + _)
        csv_out_file_id.write("\n")


    csv_out_file_id.close()
    if os.path.isfile(csv_out_file):
        print( f'The csv file {csv_out_file} were created' )
    else:   
        print( f'The csv file {csv_out_file} were not created' )
       
        

Market_list = ("dowjones","nasdaq")
#Market_list = ("sp500","dowjones","nasdaq" ,"ftse100", "ftse250","other")

sym1 = set()
sym2 = set()
sym3 = set()
sym4 = set()
sym5 = set()
sym6 = set()

# Get tickers from markets
for _ in Market_list:
    if _ == "sp500":
        Tcker1 = pd.DataFrame(si.tickers_sp500())
        sym1 = set( symbol for symbol in Tcker1[0].values.tolist())
    if _ == "nasdaq":
        Tcker2 = pd.DataFrame(si.tickers_nasdaq()) 
        sym2 = set( symbol for symbol in Tcker2[0].values.tolist())
    if _ == "dowjones":
        Tcker3 = pd.DataFrame(si.tickers_dow())
        sym3 = set( symbol for symbol in Tcker3[0].values.tolist())
    if _ == "ftse100":
        Tcker4 = pd.DataFrame(si.tickers_ftse100()) 
        sym4 = set( symbol for symbol in Tcker4[0].values.tolist())
    if _ == "ftse250":
        Tcker5 = pd.DataFrame(si.tickers_ftse250()) 
        sym5 = set( symbol for symbol in Tcker5[0].values.tolist())
    if _ == "other":
        Tcker6 = pd.DataFrame(si.tickers_other())         
        sym6 = set( symbol for symbol in Tcker6[0].values.tolist())

# join the 4 sets into one
glob_symbols = set.union( sym1, sym2, sym3, sym4, sym5, sym6)

print(len(glob_symbols))

# filter not qualified tickers
NS_list = ['W', 'R', 'P', 'Q']
NS_set = set()
good_set = set()

for __ in glob_symbols:
    if __ != "" and __ != " ":
        if len( __ ) > 4 and __[-1] in NS_list:
            NS_set.add( __ )
        else:
            good_set.add( __ )

print( f'Removed {len( NS_set )} unqualified stock symbols...' )
print( f'There are {len( good_set )} qualified stock symbols...' )

# filter ETFs and Funds
ETF_reference_file    = "Progetto\\nasdaq_etf_screener.csv"
if os.path.isfile(ETF_reference_file) == False:
        print("ETF reference file doesn't exist")
ETF_list = ETF_file_to_list(ETF_reference_file)
NO_ETF_set = list()
for __ in good_set:
    if __ not in ETF_list:
            NO_ETF_set.append(__)
print( f'There are {len( NO_ETF_set )} qualified stock symbols...' )

"""
missing_value_check(good_set)
missing_value_check(NO_ETF_set)
_input = Ref_file_to_list(Nasdaq_reference_file,NYSE_reference_file)
code_value_check(_input,good_set)
code_value_check(_input,NO_ETF_set)
"""
csv_out_file = "../Dati_file/downloaded_symbol.csv"
glob_stickers_to_csv(csv_out_file,NO_ETF_set)



