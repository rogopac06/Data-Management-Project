import json, os
from pymongo import MongoClient
import pprint
import pandas as pd

client = MongoClient('localhost', 27017)

# db_test_func = "db_company_Reddit2Mongo"
# collect_test_func = "collection_company_Reddit2Mongo"

db_local=client.db_company_Reddit2Mongo
collect_local=db_local.collect_test_func  

pd_posts = pd.read_csv("../Dati_file/Jan_Mar_2022_tickers.csv")


def Reddit2Mongo_insert_post(pd_posts,db_var,collect_local,item_symbol):
        found_item = db_var.collect_local.find({'symbol':item_symbol} )
        post_symbol = pd_posts[pd_posts['symbol'] == item_symbol ]
        if post_symbol.empty == False:
            for __ in found_item:
                timestamp_df = __['timestamp']
                len_post_symbol = len(post_symbol)
                list_ind = post_symbol.index
                post_local_list = list()
                post_temp = dict()
                new_value = timestamp_df
                print(new_value)
                for jj in list_ind:
                    single_post = post_symbol.loc[jj]
                    data_post = single_post['date']
                    post_temp[data_post] = { "author" : str(single_post['author']),
                                            "create_utc" : str(single_post['created_utc']),
                                            "id" : str(single_post['id']),
                                            "num_comments": str(single_post['num_comments']),
                                            "permalink" : str(single_post['permalink']),
                                            "subreddit" : str(single_post['subreddit']),
                                            "title" : str(single_post['title']),
                                            "date"  : str(single_post['date']),
                                            "time"  : str(single_post['time']),
                                            "symbol": str(single_post['symbol']),
                                            "text" : str(single_post['selftext']),
                                            }
                    try:
                        old_value = timestamp_df[data_post]
                        new_value[data_post] = { "Open" : old_value["Open"],
                                            "Close" : old_value["Close"],
                                            "Low" : old_value["Low"],
                                            "High":old_value["High"],
                                            "Volume" : float(old_value["Volume"]),
                                            "post" : post_temp[data_post] }
                    except:
                        print("")
                print(new_value)

                try:
                    post_id = found_item.collection.update_one(
                        {'symbol': item_symbol },
                        { '$set': {'timestamp': new_value }})  
                    print("post updated")
                except:
                    print("post not updated")
                    """
                    try:
                        post_local = post_temp[data_post]
                        post_local_list = list(post_local)
                    except:
                        post_local_list= list()
                        post_temp[data_post] = { "author" : single_post['author'],
                                                "create_utc" : single_post['created_utc'],
                                                "id" : single_post['id'],
                                                "num_comments": single_post['num_comments'],
                                                "permalink" : single_post['permalink'],
                                                "subreddit" : single_post['subreddit'],
                                                "title" : single_post['title'],
                                                "date"  : single_post['date'],
                                                "time"  : single_post['time'],
                                                "symbol": single_post['symbol'],
                                                "text" : single_post['selftext'],
                                                }
                    post_local_list.append(post_temp[data_post])
                    """
                print(post_local_list)

# get Tickers
csv_out_file = "downloaded_symbol.csv"
Tickers_download_list = read_symbols_from_file(csv_out_file)

for item_symbol in Tickers_download_list[0:4459]:
    print(item_symbol)
    Reddit2Mongo_insert_post(pd_posts,db_local,collect_local,item_symbol)