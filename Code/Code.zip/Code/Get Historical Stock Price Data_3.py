
#Get Historical Stock Price Data
import yfinance as yf
import pendulum
import matplotlib.pyplot as plt
import pandas as pd

def get_price_stickers_simple(_ticker,_period,_interval):
    stock_info = yf.Ticker(_ticker).info
    market_price = stock_info['regularMarketPrice']
    previous_close_price = stock_info['regularMarketPreviousClose']
    print('market price ', market_price)
    print('previous close price ', previous_close_price)

    price_history = yf.Ticker(_ticker).history(period=_period, # valid periods: 1d,5d,1mo,3mo,6mo,1y,2y,5y,10y,ytd,max
                               interval=_interval, # valid intervals: 1m,2m,5m,15m,30m,60m,90m,1h,1d,5d,1wk,1mo,3mo
                               actions=False)
    print(len(price_history))
    return(price_history)
    """
    time_series = list(price_history['Open'])
    dt_list = [pendulum.parse(str(dt)).float_timestamp for dt in list(price_history.index)]
    plt.style.use('dark_background')
    plt.plot(dt_list, time_series, linewidth=2)
    """

def get_price_stickers_custom_inter(_ticker,_period_start,_period_end,_interval):
    stock_info = yf.Ticker(_ticker).info
    # stock_info.keys() for other properties you can explore
    market_price = stock_info['regularMarketPrice']
    previous_close_price = stock_info['regularMarketPreviousClose']
    print('market price ', market_price)
    print('previous close price ', previous_close_price)

    price_history = yf.Ticker(_ticker).history(start=_period_start,end=_period_end,
                                               #start='2021-02-19', end='2021-02-20',
                                               interval=_interval, # valid intervals: 1m,2m,5m,15m,30m,60m,90m,1h,1d,5d,1wk,1mo,3mo
                               actions=False)
    
    print(len(price_history))
    return(price_history)

def plot_ticker_value_on_interval(price_history):
    time_series = list(price_history['Open'])
    #dt_list = [pendulum.parse(str(dt)).float_timestamp for dt in list(price_history.index)]
    dt_list = [pendulum.parse(str(dt)).format('dddd DD MMMM YYYY') for dt in list(price_history.index)]
    plt.style.use('dark_background')
    plt.xticks(ticks=range(len(dt_list)), labels=dt_list, rotation=90)
    plt.title ('Open value of a ticker during a month')
    plt.xlabel ('Day')
    plt.ylabel ('Ticker value [$]')
    plt.plot(dt_list, time_series, linewidth=2)

def get_timestamp_given_year_month(YY,MM):
    start0 = ""
    end0 = ""
    if MM == "1" or MM == "01" or MM.lower() == "jan":
        start0 = YY + "-01-01"
        end0 = YY + "-01-31"
    elif MM == "2" or MM == "02" or MM.lower() == "feb":
        start0 = YY + "-02-01"
        end0 = YY + "-02-28"     
    elif MM == "3" or MM == "03" or MM.lower() == "mar":
        start0 = YY + "-03-01"
        end0 = YY + "-03-31"   
    elif MM == "4" or MM == "04" or MM.lower() == "apr":
        start0 = YY + "-04-01"
        end0 = YY + "-04-30"     
    elif MM == "5" or MM == "05" or MM.lower() == "mai":
        start0 = YY + "-05-01"
        end0 = YY + "-05-31"         
    elif MM == "6" or MM == "06" or MM.lower() == "jun":
        start0 = YY + "-06-01"
        end0 = YY + "-06-30"     
    elif MM == "7" or MM == "07" or MM.lower() == "jul":
        start0 = YY + "-07-01"
        end0 = YY + "-07-31"       
    elif MM == "8" or MM == "08" or MM.lower() == "aug":
        start0 = YY + "-08-01"
        end0 = YY + "-08-31"         
    elif MM == "9" or MM == "09" or MM.lower() == "sep":
        start0 = YY + "-09-01"
        end0 = YY + "-09-30"    
    elif MM == "10" or MM.lower() == "oct":
        start0 = YY + "-10-01"
        end0 = YY + "-10-31"         
    elif MM == "11" or MM.lower() == "nov":
        start0 = YY + "-11-01"
        end0 = YY + "-11-30" 
    elif MM == "12" or MM.lower() == "dec":
        start0 = YY + "-12-01"
        end0 = YY + "-12-31" 
    else:
        print("Wrong dates inserted!")
        return()
    return (start0,end0)


# _period = '1mo'
# _interval = '1d'
# for _ in NO_ETF_set[:9]:
#     print(_)
#     price_ticker = get_price_stickers(_,_period,_interval)
#     print(price_ticker)

