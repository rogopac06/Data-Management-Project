import pandas as pd
import matplotlib.pyplot as plt
import seaborn; seaborn.set()


import datetime
def dateparse (time_in_secs):
    return datetime.datetime.fromtimestamp(float(time_in_secs))

from scipy.signal import argrelextrema
import numpy as np


def Peaks_detection_fromprice_history(item_symbol,_period_start,_period_end,_interval):

    price_history = get_price_stickers_custom_inter(item_symbol,_period_start,_period_end,_interval)

    ilocs_min = argrelextrema(price_history.Close.values, np.less_equal, order=2)[0]
    ilocs_max = argrelextrema(price_history.Close.values, np.greater_equal, order=2)[0]
    
    title_ticker = item_symbol + ' value [$] vs. day'
    price_history.Close.plot(figsize=(20,8), alpha=.3).set(title=title_ticker)
    price_history.Close.iloc[ilocs_max].plot(style='.', lw=10, color='red', marker="v")
    price_history.Close.iloc[ilocs_min].plot(style='.', lw=10, color='green', marker="^")
    

_period_start= "2022-01-01"
_period_end= "2022-03-31"
_interval= "1d"

item_symbol = "AAPL"

Peaks_detection_fromprice_history(item_symbol,_period_start,_period_end,_interval)