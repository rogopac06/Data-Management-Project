import json, os
from pymongo import MongoClient
import pprint



def read_symbols_from_file(csv_out_file):
    if os.path.isfile(csv_out_file) == False:
        print( f'The csv file {csv_out_file} doesn\'t exist' )
        return()
    else:   
        print( f'The csv file {csv_out_file} exists' )
        csv_out_file_id = open(csv_out_file)
        csv_line = csv_out_file_id.readlines()
        sym_list = list()
        for _ in  csv_line:
            _ =_.replace("\n","")
            sym0 = _.split(",")
            sym0 = sym0[1]
            sym_list.append(sym0)
            i=0
        sym_list = sym_list[1:]
        csv_out_file_id.close()
        return(sym_list)


def Reddit2Mongo_Create_db_coll (db_var,collection_var):
        print(db_var)
        client=MongoClient()
        db_local=client.db_var
        print(collection_var) 
        collect_local=db_local.collection_var
        

def Reddit2Mongo_insert_company(db_var,collect_local,item):
        for _ in item:
            try:
                post_id = db_var.collect_local.insert_one(
                    {
                        "symbol": _,
                        "timestamp": ""
                        #"name": str(item_name),                 
                        # "industry": str(item_industry)                   
                        }
                    ).inserted_id
                print("Company \"" + _  + "\" inserted")          
            except:
                print("Company \"" + _  + "\" not inserted")

def Tweet2Mongo_insert_company(db_var,collect_local,item):
        for _ in item.keys():
            print(_,item[_])
            item_industry = item[_][1]
            item_name = item[_][0]
            item_symbol = _
            try:
                post_id = db_var.collect_local.insert_one(
                    {
                        "symbol": str(item_symbol),
                        "name": str(item_name),                 
                        "industry": str(item_industry)                   
                        }
                    ).inserted_id
                print("Company \"" + item_name  + "\" inserted")          
            except:
                print("Company \"" + item_name  + "\" not inserted")          

def Reddit2Mongo_insert_values2(db_var,collect_local,item_symbol,_period_start,_period_end,_interval):
        found_item = db_var.collect_local.find({'symbol':item_symbol} )
        price_ticker = get_price_stickers_custom_inter(item_symbol,_period_start,_period_end,_interval)
        time_series = list(price_ticker['Open'])
        dt_list = [pendulum.parse(str(dt)).format('YYYY-MM-DD') for dt in list(price_ticker.index)]
        for __ in found_item:
            TS_local_list = list()
            list_ticker=dict()
            for _ in dt_list:
                list_ticker[_] = { "Open" : price_ticker.Open[_],
                                   "Close" : price_ticker.Close[_],
                                   "Low" : price_ticker.Low[_],
                                   "High":price_ticker.High[_],
                                   "Volume" : float(price_ticker.Volume[_])}
         
            try:
                post_id = found_item.collection.update_one(
                    {'symbol': item_symbol },
                    { '$set': {'timestamp': list_ticker }})          
            except:
                print("")
    
            
def Tweet2Mongo_insert_post(db_var,collect_local,item_symbol,post):
        for __ in item_symbol:
            found_item = db_var.collect_local.find({'symbol':item_symbol} )
            #result_it = db_var.collect_local.find({'symbol':""})
            ## check missing symbol / count == 0
            ##print(db_var.collect_local.find({'symbol':item_symbol} ).count())
            for _ in found_item:
                try: 
                    post_local = _['post']
                    post_local_list = list(post_local)
                except:
                    post_local_list= list()
                post_local_list.append(__.json)
                try:
                    post_id = db_var.collect_local.update_one(
                        {'symbol': item_symbol},
                        { "$set":{'post': post_local_list }})
                    print("Company \"" + item_symbol  + "\" updated")          
                except:
                    print("Company \"" + item_symbol  + "\" not updated") 


client = MongoClient('localhost', 27017)

# db_test_func = "db_company_Reddit2Mongo"
# collect_test_func = "collection_company_Reddit2Mongo"

# get Tickers
csv_out_file = "../Dati_file/downloaded_symbol.csv"
Tickers_download_list = read_symbols_from_file(csv_out_file)

# List_company=dict()
# List_company["AA"] = ("Alcoa","Metals Mining")
# List_company["AAC"] = ("Ares Acquisition","Blank Check / SPAC")

db_local=client.db_company_Reddit2Mongo
collect_local=db_local.collect_test_func        

Reddit2Mongo_insert_company(db_local,collect_local,Tickers_download_list)
_period_start= "2022-01-01"
_period_end= "2022-03-31"
_interval= "1d"
for item_symbol in Tickers_download_list[10:11]:
    #time.sleep(8)
    print(item_symbol)
    Reddit2Mongo_insert_values2(db_local,collect_local,item_symbol,_period_start,_period_end,_interval)




